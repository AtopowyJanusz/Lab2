package repos;

import domain.Privilege;
import domain.Users;

import java.util.ArrayList;
import java.util.List;

public class UsersRepo implements UsersRepoInterface{

    private static List<Users> db = new ArrayList<Users>();

    public UsersRepo() {
        if (db.isEmpty()) {
            Users user1 = new Users();
            user1.setUsername("Patrycja");
            user1.setPassword("pati");
            user1.setEmail("patrycja.bednarska@gmail.com");
            user1.setPrivilege(Privilege.ADMIN);

            Users user2 = new Users();
            user2.setUsername("Kacper");
            user2.setPassword("pati");
            user2.setEmail("kacper.rudy@gmail.com");
            user2.setPrivilege(Privilege.CLASSIC);

            Users user3 = new Users();
            user3.setUsername("Filip");
            user3.setPassword("pati");
            user3.setEmail("filip.krzysztofik@gmail.com");
            user3.setPrivilege(Privilege.PREMIUM);

            db.add(user1);
            db.add(user2);
            db.add(user3);
        }
    }

    public void add (Users user) {
        db.add(user);
    }

    public boolean login (Users user) {
        for (Users userDb : db) {
            if (userDb.getUsername().
                    equals(user.getUsername()) && userDb.getPassword().equals(user.getPassword())) {
                return true;
            }
        }
        return false;
    }

    public List<Users> getAllUsers() {
        return db;
    }

    public String getEmail(Users user) {
        for (Users userDb : db) {
            if (userDb.getUsername().equals(user.getUsername())) {
                return userDb.getEmail();
            }
        }
        return "There's no such user";
    }

    public String getPrivilege(Users user) {
        for (Users userDb : db) {
            if (userDb.getUsername().equals(user.getUsername())) {
                return userDb.getPrivilege().toString();
            }
        }
        return "There's no such user";
    }

    public void givePremium(Users user) {
        for (Users userDb : db) {
            if (userDb.getUsername().equals(user.getUsername())) {
                userDb.setPrivilege(Privilege.PREMIUM);
            }
        }
    }

    public void revokePremium(Users user) {
        for (Users userDb : db) {
            if (userDb.getUsername().equals(user.getUsername())) {
                userDb.setPrivilege(Privilege.CLASSIC);
            }
        }
    }
}