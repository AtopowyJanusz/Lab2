package filters;

public class RegistrationFilter {
}
