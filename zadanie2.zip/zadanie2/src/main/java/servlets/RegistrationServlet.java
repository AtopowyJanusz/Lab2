package servlets;


import domain.Privilege;
import domain.Users;
import repos.UsersRepo;
import repos.UsersRepoInterface;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Users user = retrieveUserFromRequest(request);
        UsersRepoInterface repository = new UsersRepo();

        ((UsersRepo) repository).add(user);
        response.sendRedirect("RegistrationSuccesfull.jsp");

    }

    private Users retrieveUserFromRequest(HttpServletRequest request) {
        Users result = new Users();
        result.setUsername(request.getParameter("username"));
        result.setPassword(request.getParameter("password"));
        result.setEmail(request.getParameter("email"));
        result.setPrivilege(Privilege.PREMIUM);
        return result;
    }

    public void init() {

    }

}

