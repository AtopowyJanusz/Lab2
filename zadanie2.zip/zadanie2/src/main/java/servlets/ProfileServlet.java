package servlets;

import domain.Users;
import repos.UsersRepo;
import repos.UsersRepoInterface;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("ProfileServlet")
public class ProfileServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet (HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        UsersRepoInterface repository = new UsersRepo();

        Users user = (Users) session.getAttribute("username");

        PrintWriter out = response.getWriter();

        out.println("<table border='1'>");
        out.println("<tr><th>User</th><th>Password</th><th>Email</th><th>Role</th></tr>");
        out.println("<tr><td>" + user.getUsername()
                + "</td><td>" + user.getPassword()
                + "</td><td>" + repository.getEmail(user)
                +"</td><td>" + repository.getPrivilege(user)
                + "</td></tr>");
        out.println("</table></br>");
        out.println("<a href='index.jsp'>Go to home page</a>");
    }

}
