package domain;

public enum Privilege {

        ADMIN("admin"),
        PREMIUM("premium"),
        CLASSIC("classic");

        private final String name;

        private Privilege(String privilege)  {
            name = privilege;
        }
        public String getValue() {
            return name;
        }

}
