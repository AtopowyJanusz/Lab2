package repos;

import domain.Users;

import java.util.List;

public interface UsersRepoInterface {

        void add (Users user);
        boolean login(Users user);
        List<Users> getAllUsers();
        String getEmail(Users user);
        String getPrivilege(Users user);
        void givePremium (Users user);
        void revokePremium (Users user);

}
